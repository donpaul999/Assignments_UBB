#include "Repository.h"
#include <iostream>
#include <fstream>



//Load movies
void Repository::loadMoviesFromFile()
{
    if (movieFileName == "")
        return;
    Movie movie;
    std::ifstream fin(movieFileName);
    while (fin >> movie) {
        movieList.push_back(movie);
    }
    fin.close();
}

void Repository::writeMoviesToFile()
{
    if (movieFileName == "")
        return;
    std::ofstream fout(movieFileName);
    for (const Movie& movie : movieList) {
        fout << movie << '\n';
    }
    fout.close();
}

Repository::Repository(const std::string& nameOfTheFileUsed)
{
    std::vector<Movie> userWatchList{};
    std::vector<Movie>{};
    movieFileName = nameOfTheFileUsed;
    loadMoviesFromFile();

}

Repository::~Repository()
{
    writeMoviesToFile();
}


int Repository::addMovie(const Movie& movieToAdd)
{
    auto iteratorWhereMovieIsFound = std::find(movieList.begin(), movieList.end(),  movieToAdd);
    if (iteratorWhereMovieIsFound !=  movieList.end() && movieList.size() != 0)
        return -1;
    movieList.push_back(movieToAdd);
    writeMoviesToFile();
    return 1;
}

int Repository::findMovie(std::vector<Movie> listOfMovies, const Movie& movieToSearch)
{
    if(std::find(listOfMovies.begin(), listOfMovies.end(),  movieToSearch) != movieList.end())
        return 1;
    else
        return -1;
}

int Repository::deleteMovie(const Movie& movieToDelete)
{
    auto iteratorWhereMovieIsFound = std::find(movieList.begin(), movieList.end(),  movieToDelete);
    if (iteratorWhereMovieIsFound == movieList.end())
        return -1;
    movieList.erase(iteratorWhereMovieIsFound);
    writeMoviesToFile();
    return 1;
}

int Repository::updateMovie(const Movie& movieToUpdateWith)
{
    auto iteratorWhereMovieIsFound = std::find(movieList.begin(), movieList.end(),  movieToUpdateWith);
	if (iteratorWhereMovieIsFound == movieList.end())
		return -1;
	*iteratorWhereMovieIsFound = movieToUpdateWith;
    writeMoviesToFile();
	return 1;
}

void Repository::changeFileName(const std::string& nameOfTheFileUsed)
{

    movieFileName = nameOfTheFileUsed;
    writeMoviesToFile();
}

Movie Repository::getMovieAtPosition(int positionOfMovie)
{
	if (positionOfMovie < 0 || positionOfMovie >= movieList.size())
		throw std::runtime_error("Invalid position");
	return movieList[positionOfMovie];
}

int Repository::getNumberOfMovies()
{
	return movieList.size();
}

std::vector<Movie> Repository::getMoviesByGenre(const std::string& genreGiven)
{
    std::vector<Movie> moviesWithGenre;
    std::copy_if(movieList.begin(), movieList.end(), std::back_inserter(moviesWithGenre), [&genreGiven](const Movie& movie) {return movie.getGenre() == genreGiven; });
	return moviesWithGenre;
}

std::vector<Movie> Repository::getAllMovies()
{
	return movieList;
}

std::vector<Movie> Repository::getAllWatchListMovies()
{
	return userWatchList;
}

int Repository::addMovieToWatchlist(const Movie& movieToAdd)
{
    auto iteratorWhereMovieIsFound = std::find(movieList.begin(), movieList.end(), movieToAdd);
    if (iteratorWhereMovieIsFound == movieList.end())
        return -1;
    userWatchList.push_back(movieToAdd);
    return 1;
}

int Repository::addMovieToWatchListByTitle(const std::string& titleOfTheMovieToAdd)
{
    auto iteratorWhereMovieFound = std::find_if(movieList.begin(), movieList.end(), [&titleOfTheMovieToAdd](const Movie& movie) {return movie.getTitle() == titleOfTheMovieToAdd; });
    if (iteratorWhereMovieFound == movieList.end())
        return -1;
    userWatchList.push_back(*iteratorWhereMovieFound);
    return 1;
}


int Repository::getNumberOfMoviesWatchList()
{
	return userWatchList.size();
}
