//
// Created by Paul Colta on 04/05/2020.
//

#include "HospitalDepartament.h"
