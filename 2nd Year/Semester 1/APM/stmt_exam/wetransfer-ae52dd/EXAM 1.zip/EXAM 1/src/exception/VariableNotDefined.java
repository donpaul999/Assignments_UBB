package exception;

public class VariableNotDefined extends MyException{
    public VariableNotDefined(String message){
        super(message);
    }
}
