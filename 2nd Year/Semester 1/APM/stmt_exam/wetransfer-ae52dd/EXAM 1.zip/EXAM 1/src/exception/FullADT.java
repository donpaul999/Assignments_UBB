package exception;

public class FullADT extends MyException{
    public FullADT(String message){
        super(message);
    }
}
