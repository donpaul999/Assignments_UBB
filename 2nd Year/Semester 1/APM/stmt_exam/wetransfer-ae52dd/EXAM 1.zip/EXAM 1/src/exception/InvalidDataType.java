package exception;

public class InvalidDataType extends MyException{
    public InvalidDataType(String message){
        super(message);
    }
}
