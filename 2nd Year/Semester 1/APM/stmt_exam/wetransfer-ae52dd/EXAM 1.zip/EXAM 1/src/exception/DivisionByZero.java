package exception;

public class DivisionByZero extends MyException {
    public DivisionByZero(String message){
        super(message);
    }
}
