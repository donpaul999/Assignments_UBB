package exception;

public class EmptyADT extends MyException{
    public EmptyADT(String message){
        super(message);
    }
}
