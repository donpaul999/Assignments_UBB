import controller.Controller;
import repository.Repository;
import view.View;

import java.util.Scanner;


//public class Main {

//    public static void main(String[] args) {

        /*
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter file path");

        String path = myObj.nextLine();

        Repository myRepository = new Repository(path);
        Controller myController = new Controller(myRepository,1);
        View view = new View(myController);
        view.run();

         */

//    }
//}
