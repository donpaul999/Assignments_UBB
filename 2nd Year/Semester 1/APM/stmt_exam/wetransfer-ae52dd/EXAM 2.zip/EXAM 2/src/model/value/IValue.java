package model.value;

import model.type.Type;

public interface IValue {
    Type getType();
    String toString();
}
