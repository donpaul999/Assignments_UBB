package exception;

public class ExeFinished extends MyException {
    public ExeFinished(String message) {
        super(message);
    }
}
