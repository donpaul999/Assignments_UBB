package exception;

public class EmptyStackException extends MyException {
    public EmptyStackException(String message){
        super(message);
    }
}
